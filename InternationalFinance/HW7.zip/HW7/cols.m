% number of columns
function [nc]= cols(m)

[~,nc] = size(m);

end