% function [mx,ind] = maxc(x)
function [mx] = maxc(x)

[mx,ind] = max(x);
mx = mx';

end
