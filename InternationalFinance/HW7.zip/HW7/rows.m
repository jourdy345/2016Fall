function [nr]= rows(m)

[nr,nc] = size(m);

end